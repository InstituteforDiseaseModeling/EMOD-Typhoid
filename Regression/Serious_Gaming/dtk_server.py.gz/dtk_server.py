#!/usr/bin/python

import SocketServer
import socket
import os
import time
import json

os.putenv( "GAME_MODE", "1" )

class MyTCPHandler(SocketServer.BaseRequestHandler):
    """
    The RequestHandler class for our server.

    It is instantiated once per connection to the server, and must
    override the handle() method to implement communication to the
    client.
    """

    def handle(self):
        self.request.sendall( "hello!\nType 'RUN', 'STEP', or 'KILL'\n" )
        #self.dtk_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        while True:
            try:
                # self.request is the TCP socket connected to the client
                self.data = self.request.recv(1024).strip()
                print "{} wrote:".format(self.client_address[0])
                msg = None
                print self.data
                if self.data == "RUN":
                    msg = self.run_dtk() + "\n"
                elif self.data == "KILL":
                    msg = self.kill_dtk() + "\n"
                elif self.data == "STEP":
                    msg = self.pass_through( self.data )
                else:
                    msg = self.data + " is not a recognized command.\n"
                    print( msg )
                # just send back the same data, but upper-cased
                self.request.sendall( msg )
            except Exception as ex:
                print( "Exception: assuming client disconnected. Force kill." )
                self.kill_dtk()
                return

    def run_dtk(self):
        game_port = 7887
        os.putenv( "GAME_PORT", str(game_port) )
        exec_string = "../../build/x64/Debug/Eradication/Eradication --config config.json -I . -O testing &"
        dtk_run = os.system( exec_string )
        time.sleep(2)
        self.dtk_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.dtk_socket.connect(("localhost", game_port))
        status_report = json.loads( "{}" )
        status_report["status"] = "running"
        return str( status_report )

    def kill_dtk(self):
        print( "Terminating all DTK instances." )
        os.system( "killall Eradication" )
        self.dtk_socket.close()
        status_report = json.loads( "{}" )
        status_report["status"] = "stopped"
        return str( status_report )

    def pass_through(self, msg):
        self.dtk_socket.sendall( msg )
        data = self.dtk_socket.recv( 2000 )
        return data

if __name__ == "__main__":
    HOST, PORT = "10.129.110.137", 7776

    # Create the server, binding to localhost on port 9999
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)

    # Activate the server; this will keep running until you
    # interrupt the program with Ctrl-C
    server.serve_forever()
